# VyaparDesk

A fast, installable retail business web app for PC and Android. It runs entirely in the browser and stores demo data locally.

## Run

For full PWA/install support, serve the folder over HTTP:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Demo logins

- Owner: `1000` / PIN `1234`
- Staff: `1001` / PIN `1111`

## Included

- Owner/staff ID + fast PIN login, forgot/change/reset PIN
- Invoice creation with cash/online and full/partial/unpaid status
- Invoice print, native share/copy, search, and owner-only delete
- Inventory and low-stock alerts
- Staff creation and access separation
- Attendance clock in/out and payroll baseline
- Billing statement + CSV export
- Dark/light mode, responsive Android/desktop UI, offline PWA cache

## Production note

This is a functional local-first baseline. Before real multi-device business use, connect it to a secure backend/database, replace local PIN storage with hashed authentication, add cloud sync/backups, and implement GST/tax rules as applicable.